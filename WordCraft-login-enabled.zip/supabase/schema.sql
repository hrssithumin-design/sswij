-- Run this in Supabase Dashboard → SQL Editor.
create table if not exists public.documents (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null default 'Untitled document',
  content text not null default '',
  updated_at timestamptz not null default now()
);
alter table public.documents enable row level security;
create policy "Users can read their own documents" on public.documents
  for select to authenticated using (auth.uid() = user_id);
create policy "Users can create their own documents" on public.documents
  for insert to authenticated with check (auth.uid() = user_id);
create policy "Users can update their own documents" on public.documents
  for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users can delete their own documents" on public.documents
  for delete to authenticated using (auth.uid() = user_id);
