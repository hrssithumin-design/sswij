# WordCraft

A browser-based document editor with Supabase authentication and per-user cloud documents.

## Included
- Email/password sign up and sign in
- Password reset email flow
- Google OAuth sign-in (after enabling Google in Supabase)
- Sign out
- User-private document records in Supabase, protected by Row Level Security
- Browser local draft fallback
- Rich text controls, tables, images, word count, find/replace
- DOCX, HTML and Print / Save as PDF export

## 1. Create a Supabase project
Create a project at https://supabase.com/. In **Project Settings → API**, copy the Project URL and the public anon/publishable key.

## 2. Configure environment
Copy `.env.example` to `.env` and fill in your values:

```env
VITE_SUPABASE_URL=https://YOUR-PROJECT.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_PUBLIC_ANON_OR_PUBLISHABLE_KEY
```

Only use the public anon/publishable key in frontend code. Never use a `service_role` or secret key here.

## 3. Create the documents table
Open **SQL Editor** in Supabase and run the contents of `supabase/schema.sql`. The table has Row Level Security policies so each signed-in user can only access their own documents.

## 4. Configure authentication
In **Authentication → URL Configuration**, set your Site URL to your deployed app URL (for local development use `http://localhost:5173`) and add your redirect URLs.

Email/password is ready once the project is configured. For Google login:
1. In Supabase, open **Authentication → Providers → Google** and enable it.
2. Add the Google OAuth Client ID and Client Secret from Google Cloud Console.
3. Add the Supabase callback URL shown in the provider settings to the Google OAuth authorized redirect URIs.
4. Add your local and deployed app URLs to Supabase's allowed redirect URLs.

For production, configure SMTP/email delivery in Supabase so confirmation and password reset emails reliably reach users.

## 5. Run
Node.js 18+:

```bash
npm install
npm run dev
```

Open the Vite URL, normally `http://localhost:5173`.

Build for deployment:

```bash
npm run build
npm run preview
```

## Important notes
- Authentication and cloud document storage require a configured Supabase project. This source package does not include or create a Supabase account/project for you.
- The app stores the current working draft in the browser as a fallback; cloud documents are stored in Supabase.
- The DOCX export currently preserves the document's text content in paragraphs; for complex layouts, use HTML or Print / PDF export.
- For a public deployment, use HTTPS and set the correct Supabase Site URL and redirect allowlist.
